//
//  ViewController.swift
//  TicTacToe
//
//  Created by Blanca Gutierrez on 2/6/19.
//  Copyright © 2019 SchoolProjects. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var button1Text: UIButton!
    @IBOutlet var button2Text: UIButton!
    @IBOutlet var button3Text: UIButton!
    @IBOutlet var button4Text: UIButton!
    @IBOutlet var button5Text: UIButton!
    @IBOutlet var button6Text: UIButton!
    @IBOutlet var button7Text: UIButton!
    @IBOutlet var button8Text: UIButton!
    @IBOutlet var button9Text: UIButton!
    
    @IBOutlet var winnerLabel: UILabel!
    
    var winCheck: [Int] = []
    
    var player: String = "one"
    var slotsUsed: Int = 0
    
    
    override func viewDidLoad(){
        super.viewDidLoad()
        
        //initalize the tic tac toe game to empty slots
        button1Text.setTitle("",for: .normal)
        button2Text.setTitle("",for: .normal)
        button3Text.setTitle("",for: .normal)
        button4Text.setTitle("",for: .normal)
        button5Text.setTitle("",for: .normal)
        button6Text.setTitle("",for: .normal)
        button7Text.setTitle("",for: .normal)
        button8Text.setTitle("",for: .normal)
        button9Text.setTitle("",for: .normal)
        
        player = "one"
        slotsUsed = 0
        winnerLabel.text = ""
    }
    
    @IBAction func restartGame(){
        slotsUsed = 0
        player = "one"
        winnerLabel.text = ""
        button1Text.setTitle("", for: .normal)
        button2Text.setTitle("", for: .normal)
        button3Text.setTitle("", for: .normal)
        button4Text.setTitle("", for: .normal)
        button5Text.setTitle("", for: .normal)
        button6Text.setTitle("", for: .normal)
        button7Text.setTitle("", for: .normal)
        button8Text.setTitle("", for: .normal)
        button9Text.setTitle("", for: .normal)
        
        button1Text.isEnabled = true
        button2Text.isEnabled = true
        button3Text.isEnabled = true
        button4Text.isEnabled = true
        button5Text.isEnabled = true
        button6Text.isEnabled = true
        button7Text.isEnabled = true
        button8Text.isEnabled = true
        button9Text.isEnabled = true
    }

    @IBAction func button1() {
        if(button1Text.title(for: UIControl.State.normal) == ""){
                print("button1")
                slotsUsed += 1
                
                if (player == "one"){
                    button1Text.setTitle("O", for: .normal)
                    
                    player = "two"
                }
                else if(player == "two"){
                    button1Text.setTitle("X", for: .normal)
                    player = "one"
                }
                winCheck.append(1)
                
                print(slotsUsed)
                if(slotsUsed > 0){
                    declareWinner()
                }
            }
    }
    
    @IBAction func button2() {
        if(button2Text.title(for: UIControl.State.normal) == ""){
            print("button2")
            slotsUsed += 1
            
            if (player == "one"){
                button2Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button2Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            print(slotsUsed)
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }

    @IBAction func button3() {
        if(button3Text.title(for: UIControl.State.normal) == ""){
            print("button3")
            slotsUsed += 1
            
            if (player == "one"){
                button3Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button3Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }
    
    @IBAction func button4() {
        if(button4Text.title(for: UIControl.State.normal) == ""){
            print("button4")
            slotsUsed += 1
            
            if (player == "one"){
                button4Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button4Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            print(slotsUsed)
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }
    
    @IBAction func button5() {
        if(button5Text.title(for: UIControl.State.normal) == ""){
            print("button5")
            slotsUsed += 1
            
            if (player == "one"){
                button5Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button5Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            print(slotsUsed)
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }

    @IBAction func button6() {
        if(button6Text.title(for: UIControl.State.normal) == ""){
            print("button6")
            slotsUsed += 1
            
            if (player == "one"){
                button6Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button6Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            print(slotsUsed)
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }
    
    @IBAction func button7() {
        if(button7Text.title(for: UIControl.State.normal) == ""){
            print("button7")
            slotsUsed += 1
            
            if (player == "one"){
                button7Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button7Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            print(slotsUsed)
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }
    
    @IBAction func button8() {
        if(button8Text.title(for: UIControl.State.normal) == ""){
            print("button8")
            slotsUsed += 1
            
            if (player == "one"){
                button8Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button8Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            print(slotsUsed)
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }
    
    @IBAction func button9() {
        if(button9Text.title(for: UIControl.State.normal) == ""){
            print("button9")
            slotsUsed += 1
            
            if (player == "one"){
                button9Text.setTitle("O", for: .normal)
                player = "two"
            }
            else if(player == "two"){
                button9Text.setTitle("X", for: .normal)
                player = "one"
            }
            winCheck.append(1)
            
            print(slotsUsed)
            if(slotsUsed > 0){
                declareWinner()
            }
        }
    }
    func declareWinner(){
        
        if(button1Text.title(for: UIControl.State.normal) == "O" && button2Text.title(for: UIControl.State.normal) == "O" && button3Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
            
        }
        else if(button1Text.title(for: UIControl.State.normal) == "X" && button2Text.title(for: UIControl.State.normal) == "X" && button3Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button4Text.title(for: UIControl.State.normal) == "X" && button5Text.title(for: UIControl.State.normal) == "X" && button6Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button4Text.title(for: UIControl.State.normal) == "O" && button5Text.title(for: UIControl.State.normal) == "O" && button6Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
            
        }
        else if(button7Text.title(for: UIControl.State.normal) == "X" && button8Text.title(for: UIControl.State.normal) == "X" && button9Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button7Text.title(for: UIControl.State.normal) == "O" && button8Text.title(for: UIControl.State.normal) == "O" && button9Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
            
        }
        else if(button1Text.title(for: UIControl.State.normal) == "O" && button4Text.title(for: UIControl.State.normal) == "O" && button7Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
            
        }
        else if(button1Text.title(for: UIControl.State.normal) == "X" && button4Text.title(for: UIControl.State.normal) == "X" && button7Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button2Text.title(for: UIControl.State.normal) == "O" && button5Text.title(for: UIControl.State.normal) == "O" && button8Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
            
        }
        else if(button2Text.title(for: UIControl.State.normal) == "X" && button5Text.title(for: UIControl.State.normal) == "X" && button8Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button3Text.title(for: UIControl.State.normal) == "X" && button6Text.title(for: UIControl.State.normal) == "X" && button9Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button3Text.title(for: UIControl.State.normal) == "O" && button6Text.title(for: UIControl.State.normal) == "O" && button9Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
            
        }
        else if(button1Text.title(for: UIControl.State.normal) == "X" && button5Text.title(for: UIControl.State.normal) == "X" && button9Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button1Text.title(for: UIControl.State.normal) == "O" && button5Text.title(for: UIControl.State.normal) == "O" && button9Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
            
        }
        else if(button3Text.title(for: UIControl.State.normal) == "X" && button5Text.title(for: UIControl.State.normal) == "X" && button7Text.title(for: UIControl.State.normal) == "X"){
            winnerLabel.text = "Player 2 Wins"
            
            
        }
        else if(button3Text.title(for: UIControl.State.normal) == "O" && button5Text.title(for: UIControl.State.normal) == "O" && button7Text.title(for: UIControl.State.normal) == "O"){
            winnerLabel.text = "Player 1 Wins"
            
        }
        
        else if(slotsUsed == 9 && (winnerLabel.text != "Player 1 Wins" || winnerLabel.text != "Player 2 Wins")){
            winnerLabel.text = "NO WINNER"
            
        }
        
        if(winnerLabel.text == "Player 1 Wins" || winnerLabel.text == "Player 2 Wins"){
            button1Text.isEnabled = false
            button2Text.isEnabled = false
            button3Text.isEnabled = false
            button4Text.isEnabled = false
            button5Text.isEnabled = false
            button6Text.isEnabled = false
            button7Text.isEnabled = false
            button8Text.isEnabled = false
            button9Text.isEnabled = false
        }
    }
}
