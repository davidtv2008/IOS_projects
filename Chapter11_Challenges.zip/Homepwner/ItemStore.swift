//
//  ItemStore.swift
//  Homepwner
//
//  Created by Blanca Gutierrez on 2/13/19.
//  Copyright © 2019 SchoolProjects. All rights reserved.
//

import UIKit

class ItemStore{
    
    var allItems = [Item]()
    
    @discardableResult func createItem () -> Item {
        var newItem = Item ()
        
        if allItems.count == 0 {
            newItem = Item(random: false)
            newItem.accessibilityHint = "emptyItem"
        } else {
            newItem = Item(random: true)
            newItem.accessibilityHint = newItem.name
        }
        
        allItems.insert(newItem, at: 0)
        
        return newItem
    }
    
    init() {
        for _ in 0..<1 {
            createItem()
        }
    }
    
    func moveItem(from fromIndex: Int, to toIndex: Int){
        if fromIndex == toIndex{
            return
        }
        
        let movedItem = allItems[fromIndex]
        
        allItems.remove(at: fromIndex)
        
        allItems.insert(movedItem, at: toIndex)
    }
    
    func removeItem(_ item: Item){
        if let index = allItems.index(of: item){
            allItems.remove(at: index)
        }
    }
    
    
}
